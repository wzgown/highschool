#!/bin/bash
# ============================================
#  highschool 数据库恢复脚本
#  用法: bash restore.sh
# ============================================
set -e

DUMP_FILE="highschool_2026_backup.sql"
DB_NAME="highschool"
DB_USER="highschool"
CONTAINER="highschool_postgres"

echo "=== highschool 数据库恢复 ==="
echo "数据库: ${DB_NAME}  容器: ${CONTAINER}"
echo ""

if [ ! -f "$DUMP_FILE" ]; then
    echo "❌ 错误: 找不到 $DUMP_FILE"
    exit 1
fi

echo "⏳ 正在恢复数据库..."
docker cp "$DUMP_FILE" "${CONTAINER}:/tmp/${DUMP_FILE}"
docker exec "${CONTAINER}" psql -U "${DB_USER}" -d "${DB_NAME}" -f "/tmp/${DUMP_FILE}"
docker exec "${CONTAINER}" rm -f "/tmp/${DUMP_FILE}"

echo ""
echo "✅ 恢复完成！"
echo ""
echo "验证:"
docker exec "${CONTAINER}" psql -U "${DB_USER}" -d "${DB_NAME}" -c "
SELECT 'ref_school' as tbl, COUNT(*) FROM ref_school
UNION ALL SELECT 'ref_district', COUNT(*) FROM ref_district
UNION ALL SELECT 'ref_quota_allocation_district (2026)', COUNT(*) FROM ref_quota_allocation_district WHERE year=2026
UNION ALL SELECT 'ref_quota_allocation_school (2026)', COUNT(*) FROM ref_quota_allocation_school WHERE year=2026
ORDER BY 2 DESC;
"
